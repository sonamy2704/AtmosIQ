# 🔑 How to Set Up Google & GitHub Login

## ── Google Login Setup ──────────────────────────────────

### Step 1 — Go to Google Cloud Console
Open: https://console.cloud.google.com

### Step 2 — Create a Project
- Click "Select a project" at top → "New Project"
- Name it: SkyAgent → Click Create

### Step 3 — Enable OAuth
- Left menu → "APIs & Services" → "OAuth consent screen"
- Choose "External" → Click Create
- Fill in App name: SkyAgent, your email → Save

### Step 4 — Create Credentials  
- Left menu → "APIs & Services" → "Credentials"
- Click "+ CREATE CREDENTIALS" → "OAuth 2.0 Client IDs"
- Application type: Web application
- Name: SkyAgent
- Under "Authorized redirect URIs" click ADD URI:
  → Type: http://localhost:3001/auth/google/callback
- Click CREATE

### Step 5 — Copy the keys
You'll see a popup with:
- Client ID    → copy this
- Client Secret → copy this

### Step 6 — Add to .env file
Open backend/.env and set:
```
GOOGLE_CLIENT_ID=paste_your_client_id_here
GOOGLE_CLIENT_SECRET=paste_your_client_secret_here
```

---

## ── GitHub Login Setup ──────────────────────────────────

### Step 1 — Go to GitHub Settings
Open: https://github.com/settings/developers

### Step 2 — New OAuth App
- Click "New OAuth App"
- Fill in:
  - Application name: SkyAgent
  - Homepage URL: http://localhost:3001
  - Authorization callback URL: http://localhost:3001/auth/github/callback
- Click "Register application"

### Step 3 — Copy the keys
- Copy the Client ID shown on screen
- Click "Generate a new client secret" → copy it immediately!

### Step 4 — Add to .env file
Open backend/.env and set:
```
GITHUB_CLIENT_ID=paste_your_client_id_here
GITHUB_CLIENT_SECRET=paste_your_client_secret_here
```

---

## ── Restart the server ──────────────────────────────────

After adding keys to .env:
1. Stop server: Ctrl+C in the terminal
2. Start again: npm run dev
3. Open: http://localhost:3001
4. Google and GitHub buttons will now work! ✅

---

## ⚠️ Common Errors

| Error | Fix |
|-------|-----|
| "invalid_client" | Wrong Client ID in .env — copy it again carefully |
| "redirect_uri_mismatch" | Callback URL in Google/GitHub doesn't match exactly |
| Button grayed out | Keys not added to .env yet |
| Server not restarted | Always restart after changing .env |
