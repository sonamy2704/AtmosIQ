/**
 * AtmosIQ v2.0 — Advanced AI Weather Intelligence Platform
 * Upgrades: Socket.io real-time, ML predictions, NLP trip planner,
 * JWT auth, microservices pattern, admin panel, smart recommendations
 */

const express      = require('express');
const cors         = require('cors');
const axios        = require('axios');
const session      = require('express-session');
const rateLimit    = require('express-rate-limit');
const passport     = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const GitHubStrategy = require('passport-github2').Strategy;
const bcrypt       = require('bcryptjs');
const path         = require('path');
const mongoose     = require('mongoose');
const MongoStore   = require('connect-mongo');
const http         = require('http');
require('dotenv').config();

const app    = express();
const server = http.createServer(app);
const PORT     = process.env.PORT || 3001;
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;
const MONGO_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/atmosiq';
const OWM_BASE  = 'https://api.openweathermap.org/data/2.5';
const API_KEY   = process.env.OPENWEATHER_API_KEY || '';

// ── Socket.io (real-time weather) ──────────────────────────────────
let io;
try {
  const { Server } = require('socket.io');
  io = new Server(server, { cors: { origin: '*', methods: ['GET','POST'] } });
  console.log('🔌 Socket.io loaded');
} catch(e) {
  console.warn('⚠️  Socket.io not installed — install with: npm install socket.io');
  io = { on: ()=>{}, to: ()=>({ emit: ()=>{} }), emit: ()=>{} };
}

// ═══════════════════════════════════════════════════════════════════
// MONGODB
// ═══════════════════════════════════════════════════════════════════
let dbConnected = false;
mongoose.connect(MONGO_URI)
  .then(() => { dbConnected = true; console.log('✅ MongoDB connected'); })
  .catch(err => console.warn('⚠️  MongoDB in-memory mode:', err.message));

// ── Schemas ────────────────────────────────────────────────────────
const userSchema = new mongoose.Schema({
  email:     { type: String, unique: true, sparse: true, lowercase: true, trim: true },
  password:  { type: String, select: false },
  firstName: { type: String, required: true, trim: true },
  lastName:  { type: String, default: '', trim: true },
  avatar:    { type: String, default: '' },
  provider:  { type: String, enum: ['email','google','github'], default: 'email' },
  googleId:  { type: String, sparse: true },
  githubId:  { type: String, sparse: true },
  role:      { type: String, enum: ['user','admin'], default: 'user' },
  preferences: {
    tempUnit:     { type: String, default: 'C' },
    defaultCity:  { type: String, default: '' },
    tempPref:     { type: String, default: '' },
    activities:   [String],
    pinnedCities: { type: [String], default: ['Mumbai','London','New York'] },
    theme:        { type: String, default: 'dark' },
    notifications:{ type: Boolean, default: false }
  },
  stats: {
    totalSearches:  { type: Number, default: 0 },
    citiesSearched: { type: Number, default: 0 },
    lastActive:     { type: Date, default: Date.now }
  },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});
userSchema.pre('save', function(next) { this.updatedAt = new Date(); next(); });
const User = mongoose.model('User', userSchema);

const searchSchema = new mongoose.Schema({
  userId:   { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  city:     { type: String, required: true },
  country:  { type: String, default: '' },
  lat: Number, lon: Number,
  weatherSnapshot: { temp: Number, condition: String, weather_main: String, humidity: Number, wind_speed: Number },
  mlPrediction:    { rainProb: Number, tempTrend: String, confidence: Number },
  searchedAt: { type: Date, default: Date.now, index: true }
});
const Search = mongoose.model('Search', searchSchema);

const tripSchema = new mongoose.Schema({
  userId:      { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  destination: { type: String, required: true },
  fromDate: Date, toDate: Date,
  budget: Number, travelers: { type: Number, default: 1 }, preferences: String,
  forecast: [mongoose.Schema.Types.Mixed], packingList: [String],
  itinerary: [mongoose.Schema.Types.Mixed], budgetPlan: mongoose.Schema.Types.Mixed,
  notes: String, nlpQuery: String,
  createdAt: { type: Date, default: Date.now }
});
const Trip = mongoose.model('Trip', tripSchema);

const alertSchema = new mongoose.Schema({
  userId:  { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  city:    { type: String, required: true },
  type:    { type: String, enum: ['rain','extreme_heat','storm','snow','wind','custom'], required: true },
  threshold: Number, message: String,
  active:  { type: Boolean, default: true },
  triggeredAt: Date,
  createdAt: { type: Date, default: Date.now }
});
const Alert = mongoose.model('Alert', alertSchema);

const chatSchema = new mongoose.Schema({
  userId:  { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  role:    { type: String, enum: ['user','agent'], required: true },
  message: String, city: String,
  ts: { type: Date, default: Date.now, index: true }
});
const Chat = mongoose.model('Chat', chatSchema);

const locationSchema = new mongoose.Schema({
  userId:   { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  name: String, city: String, country: String,
  lat: Number, lon: Number, emoji: { type: String, default: '📍' },
  isPinned: { type: Boolean, default: true }, order: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now }
});
const Location = mongoose.model('Location', locationSchema);

// ── In-memory fallback ─────────────────────────────────────────────
const memUsers = [];
const memOtpStore = {};
function memFindUser(email)  { return memUsers.find(u => u.email === email?.toLowerCase()); }
function memFindById(id)     { return memUsers.find(u => u.id === id); }
function memCreateUser(data) {
  const u = { id: Date.now().toString(), ...data, role:'user', createdAt: new Date(),
    preferences: { pinnedCities:['Mumbai','London','New York'], activities:[], tempUnit:'C', defaultCity:'' },
    stats: { totalSearches:0, citiesSearched:0 } };
  memUsers.push(u); return u;
}

// ── DB Adapter ─────────────────────────────────────────────────────
const DB = {
  async findUserByEmail(e) {
    if (dbConnected) return User.findOne({ email: e?.toLowerCase() }).select('+password');
    return memFindUser(e);
  },
  async findUserById(id) {
    if (dbConnected) { try { return User.findById(id); } catch(e){ return null; } }
    return memFindById(id);
  },
  async findUserByOAuth(field, value) {
    if (dbConnected) return User.findOne({ [field]: value });
    return memUsers.find(u => u[field] === value) || null;
  },
  async createUser(data) {
    if (dbConnected) { const u = new User(data); await u.save(); return u; }
    return memCreateUser(data);
  },
  async updateUser(id, updates) {
    if (dbConnected) return User.findByIdAndUpdate(id, { ...updates, updatedAt: new Date() }, { new: true });
    const u = memFindById(id); if (u) Object.assign(u, updates); return u;
  },
  async saveSearch(userId, data) {
    if (!dbConnected) return;
    try { await new Search({ userId, ...data }).save(); } catch(e){}
    try { await User.findByIdAndUpdate(userId, { $inc: { 'stats.totalSearches': 1 }, $set: { 'stats.lastActive': new Date() } }); } catch(e){}
  },
  async getSearchHistory(userId, limit=20) {
    if (!dbConnected) return [];
    return Search.find({ userId }).sort({ searchedAt: -1 }).limit(limit).lean();
  },
  async saveChatMessage(userId, role, message, city='') {
    if (!dbConnected) return;
    try { await new Chat({ userId, role, message, city }).save(); } catch(e){}
  },
  async getTrips(userId) {
    if (!dbConnected) return [];
    return Trip.find({ userId }).sort({ createdAt: -1 }).limit(10).lean();
  },
  async saveTrip(userId, data) {
    if (!dbConnected) return { _id: 'mem-' + Date.now() };
    return new Trip({ userId, ...data }).save();
  },
  async getAlerts(userId) {
    if (!dbConnected) return [];
    return Alert.find({ userId, active: true }).lean();
  },
  async createAlert(userId, data) {
    if (!dbConnected) return { _id: 'mem-' + Date.now(), ...data };
    return new Alert({ userId, ...data }).save();
  },
  async deleteAlert(userId, alertId) {
    if (!dbConnected) return;
    return Alert.findOneAndDelete({ _id: alertId, userId });
  },
  async saveLocation(userId, data) {
    if (!dbConnected) return null;
    const existing = await Location.findOne({ userId, city: data.city });
    if (existing) return existing;
    const count = await Location.countDocuments({ userId });
    return new Location({ userId, ...data, order: count }).save();
  },
  async getLocations(userId) {
    if (!dbConnected) return [];
    return Location.find({ userId }).sort({ order: 1 }).lean();
  },
  async getUserStats(userId) {
    if (!dbConnected) return { searches:0, cities:0, chats:0, trips:0, alerts:0 };
    const [searches, cities, chats, trips, alerts] = await Promise.all([
      Search.countDocuments({ userId }),
      Search.distinct('city', { userId }).then(a => a.length),
      Chat.countDocuments({ userId }),
      Trip.countDocuments({ userId }),
      Alert.countDocuments({ userId, active: true })
    ]);
    return { searches, cities, chats, trips, alerts };
  },
  async getAdminStats() {
    if (!dbConnected) return { totalUsers: memUsers.length, totalSearches: 0, topCities: [], recentSearches: [] };
    const [totalUsers, totalSearches, topCities, recentSearches, newUsersToday] = await Promise.all([
      User.countDocuments(),
      Search.countDocuments(),
      Search.aggregate([{ $group: { _id: '$city', count: { $sum: 1 } } }, { $sort: { count: -1 } }, { $limit: 10 }]),
      Search.find().sort({ searchedAt: -1 }).limit(15).lean(),
      User.countDocuments({ createdAt: { $gte: new Date(Date.now() - 86400000) } })
    ]);
    return { totalUsers, totalSearches, topCities, recentSearches, newUsersToday };
  }
};

// ═══════════════════════════════════════════════════════════════════
// ML ENGINE (Node-based RandomForest simulation)
// ═══════════════════════════════════════════════════════════════════
const ML = {
  predictRainProbability(wd) {
    const { humidity, weather_main, temp, pressure, wind_speed } = wd;
    const main = (weather_main || '').toLowerCase();
    let prob = 0;
    if (main === 'rain' || main === 'drizzle') prob += 75;
    else if (main === 'thunderstorm') prob += 90;
    else if (main === 'clouds') prob += 30;
    else if (main === 'clear') prob -= 10;
    else if (main === 'mist' || main === 'fog') prob += 45;
    if (humidity > 85) prob += 25;
    else if (humidity > 70) prob += 15;
    else if (humidity > 55) prob += 8;
    else if (humidity < 40) prob -= 15;
    if (pressure < 1000) prob += 20;
    else if (pressure < 1010) prob += 10;
    else if (pressure > 1025) prob -= 10;
    if (wind_speed > 40) prob += 10;
    const value = Math.max(0, Math.min(100, prob + Math.floor(Math.random() * 8 - 4)));
    return { value, confidence: +(0.78 + Math.random() * 0.15).toFixed(2) };
  },

  predictTemperatureTrend(currentTemp, forecast) {
    if (!forecast || forecast.length < 2) return { trend: 'stable', delta: 0, confidence: 0.60 };
    const avg3Day = forecast.slice(0, 3).reduce((s, d) => s + (d.temp || 0), 0) / 3;
    const delta = avg3Day - currentTemp;
    const trend = delta > 2 ? 'rising' : delta < -2 ? 'falling' : 'stable';
    return { trend, delta: Math.round(delta * 10) / 10, confidence: +(0.72 + Math.random() * 0.20).toFixed(2) };
  },

  generateSmartAlerts(wd) {
    const alerts = [];
    const { temp, weather_main, wind_speed, humidity } = wd;
    const main = (weather_main || '').toLowerCase();
    if (temp >= 42) alerts.push({ level: 'critical', icon: '🔴', message: `Extreme heat: ${temp}°C — Stay indoors, hydrate constantly` });
    else if (temp >= 38) alerts.push({ level: 'high', icon: '🟠', message: `Heat advisory: ${temp}°C — Limit sun exposure` });
    if (main === 'thunderstorm') alerts.push({ level: 'critical', icon: '⛈️', message: 'Severe thunderstorm — Seek shelter immediately' });
    if (main === 'snow') alerts.push({ level: 'medium', icon: '❄️', message: 'Snowfall — Watch for icy surfaces' });
    if (wind_speed > 60) alerts.push({ level: 'high', icon: '💨', message: `Strong wind: ${wind_speed} km/h — Secure loose items` });
    if (humidity > 90) alerts.push({ level: 'medium', icon: '💧', message: `Extreme humidity: ${humidity}% — Stay cool` });
    if (temp <= 2) alerts.push({ level: 'high', icon: '🥶', message: `Near-freezing: ${temp}°C — Risk of frostbite` });
    return alerts;
  }
};

// ═══════════════════════════════════════════════════════════════════
// NLP TRIP PLANNER
// ═══════════════════════════════════════════════════════════════════
const NLP = {
  parseTripQuery(query) {
    const q = query.toLowerCase();
    const result = { destination: null, budget: null, duration: null, tempPreference: null, travelers: 1, tripType: 'general', month: null };
    const daysMatch = q.match(/(\d+)[- ]?days?/i);
    const weekMatch = q.match(/(\d+)[- ]?weeks?/i);
    if (daysMatch) result.duration = parseInt(daysMatch[1]);
    else if (weekMatch) result.duration = parseInt(weekMatch[1]) * 7;
    const budgetMatch = q.match(/(?:under|within|budget|below)?\s*(?:₹|\$|rs\.?)?\s*(\d+)\s*(?:k|thousand|lakh)?/i);
    if (budgetMatch) {
      let b = parseFloat(budgetMatch[1]);
      if (/k|thousand/.test(q)) b *= 1000;
      else if (/lakh/.test(q)) b *= 100000;
      if (b >= 500) result.budget = b;
    }
    if (/cold|snowy|winter|hill|mountain|snow|cool/i.test(q)) result.tempPreference = 'cold';
    else if (/hot|beach|tropical|summer|warm|sunny/i.test(q)) result.tempPreference = 'hot';
    else if (/mild|pleasant|comfortable/i.test(q)) result.tempPreference = 'mild';
    if (/adventure|trek|hike|camping/i.test(q)) result.tripType = 'adventure';
    else if (/beach|sea|ocean|coastal/i.test(q)) result.tripType = 'beach';
    else if (/budget|cheap|affordable/i.test(q)) result.tripType = 'budget';
    else if (/luxury|resort|spa|5 star/i.test(q)) result.tripType = 'luxury';
    else if (/family|kids|children/i.test(q)) result.tripType = 'family';
    else if (/solo|alone|backpack/i.test(q)) result.tripType = 'solo';
    else if (/romantic|couple|honeymoon/i.test(q)) result.tripType = 'romantic';
    const travelers = q.match(/(\d+)\s*(?:people|persons|travelers|friends)/i);
    if (travelers) result.travelers = parseInt(travelers[1]);
    return result;
  },

  suggestDestinations(parsed) {
    const all = {
      cold: [
        { city:'Manali', country:'India', desc:'Snow-capped peaks & adventure sports', avgTemp:'5°C', budget:'₹8k–15k', emoji:'🏔️' },
        { city:'Shimla', country:'India', desc:'Colonial charm, mountain views', avgTemp:'10°C', budget:'₹6k–12k', emoji:'🌲' },
        { city:'Leh', country:'India', desc:'High-altitude adventure, Pangong Lake', avgTemp:'2°C', budget:'₹15k–25k', emoji:'🏕️' },
        { city:'Ooty', country:'India', desc:'Nilgiri hills and tea gardens', avgTemp:'15°C', budget:'₹5k–10k', emoji:'🌿' },
        { city:'Darjeeling', country:'India', desc:'Tea estates, Himalayan panoramas', avgTemp:'12°C', budget:'₹7k–14k', emoji:'☕' }
      ],
      hot: [
        { city:'Goa', country:'India', desc:'Beaches, nightlife, water sports', avgTemp:'28°C', budget:'₹10k–20k', emoji:'🏖️' },
        { city:'Andaman', country:'India', desc:'Crystal waters, coral reefs', avgTemp:'27°C', budget:'₹20k–35k', emoji:'🐠' },
        { city:'Pondicherry', country:'India', desc:'French colony, beaches, yoga', avgTemp:'29°C', budget:'₹6k–12k', emoji:'🧘' },
        { city:'Kerala', country:'India', desc:'Backwaters, ayurveda, nature', avgTemp:'30°C', budget:'₹8k–18k', emoji:'🌴' },
        { city:'Bali', country:'Indonesia', desc:'Tropical paradise, temples, surfing', avgTemp:'28°C', budget:'₹40k–80k', emoji:'🛕' }
      ],
      mild: [
        { city:'Coorg', country:'India', desc:'Coffee estates, misty hills', avgTemp:'20°C', budget:'₹8k–15k', emoji:'☕' },
        { city:'Munnar', country:'India', desc:'Tea valleys, wildlife, waterfalls', avgTemp:'18°C', budget:'₹7k–13k', emoji:'🍃' },
        { city:'Nainital', country:'India', desc:'Lake city, mountain walks', avgTemp:'16°C', budget:'₹5k–10k', emoji:'🏞️' },
        { city:'Kodaikanal', country:'India', desc:'Princess of hill stations', avgTemp:'17°C', budget:'₹6k–11k', emoji:'🌸' },
        { city:'Mussoorie', country:'India', desc:'Queen of hills, Kempty Falls', avgTemp:'14°C', budget:'₹6k–12k', emoji:'🌊' }
      ]
    };
    const pref = parsed.tempPreference || 'mild';
    let list = all[pref] || all.mild;
    if (parsed.budget) {
      const filtered = list.filter(d => {
        const min = parseInt(d.budget.replace(/[₹k–\d\s]/g,'').split('–')[0]) * 1000;
        return min <= parsed.budget;
      });
      if (filtered.length > 0) list = filtered;
    }
    return list.slice(0, 3);
  },

  generateItinerary(destination, duration, tripType, forecast) {
    const activities = {
      adventure:['Morning trek to nearby peaks','River rafting / zip-lining','Rock climbing session','Visit local waterfalls','Night sky camping'],
      beach:['Sunrise beach walk','Water sports (snorkeling/surfing)','Visit beach shacks for seafood','Sunset cruise','Parasailing or scuba diving'],
      budget:['Explore local markets','Street food tour','Free walking tour','Visit public parks','Sunset viewpoint'],
      luxury:['Spa & wellness session','Fine dining experience','Private city tour','Cultural show & dinner','Helicopter sightseeing'],
      family:['Visit theme parks / zoos','Museum tour','Boat ride or nature walk','Local cuisine experience','Souvenir shopping'],
      romantic:['Candlelit dinner','Sunset viewpoint','Couples spa','Private boat cruise','Stargazing night'],
      general:['Explore city centre','Visit famous landmarks','Local cuisine tour','Cultural museum','Evening market walk']
    };
    const acts = activities[tripType] || activities.general;
    const days = [];
    for (let i = 0; i < Math.min(duration || 3, 7); i++) {
      const fc = forecast?.[Math.min(i, (forecast?.length||1) - 1)];
      days.push({
        day: i + 1,
        date: new Date(Date.now() + i * 86400000).toLocaleDateString('en-IN', { weekday:'long', day:'numeric', month:'short' }),
        forecast: fc ? `${fc.temp_max}°/${fc.temp_min}° — ${fc.condition}` : 'Forecast unavailable',
        weatherEmoji: fc ? ({'Clear':'☀️','Clouds':'⛅','Rain':'🌧️','Snow':'❄️','Thunderstorm':'⛈️'}[fc.weather_main] || '🌤️') : '📅',
        activities: [
          `🌅 Morning: ${acts[i % acts.length]}`,
          `☀️ Afternoon: ${i === 0 ? 'Hotel check-in, freshen up, explore nearby area' : 'Local lunch, afternoon exploration & photography'}`,
          `🌙 Evening: ${i === Math.min(duration||3,7)-1 ? 'Final souvenir shopping & farewell dinner' : 'Sunset views, dinner, evening stroll'}`
        ],
        tip: i === 0 ? '💡 Pack light; carry sunscreen and a rain jacket'
           : i === Math.min(duration||3,7)-1 ? '💡 Check checkout time, arrange airport transfer early'
           : '💡 Stay hydrated and keep local emergency numbers handy'
      });
    }
    return days;
  },

  generateBudgetPlan(destination, duration, travelers, budget, tripType) {
    const days = duration || 3;
    const pax  = travelers || 1;
    const total = budget || (tripType==='luxury' ? 30000 : tripType==='budget' ? 5000 : 15000) * pax;
    const alloc = tripType==='luxury'
      ? { hotel:0.40, food:0.20, transport:0.15, activities:0.15, shopping:0.10 }
      : tripType==='budget'
      ? { hotel:0.30, food:0.30, transport:0.20, activities:0.10, shopping:0.10 }
      : { hotel:0.35, food:0.25, transport:0.15, activities:0.15, shopping:0.10 };
    return {
      total, perDay: Math.round(total/days), perPerson: Math.round(total/pax),
      breakdown: {
        hotel:      Math.round(total * alloc.hotel),
        food:       Math.round(total * alloc.food),
        transport:  Math.round(total * alloc.transport),
        activities: Math.round(total * alloc.activities),
        shopping:   Math.round(total * alloc.shopping)
      },
      hotelCategory: tripType==='luxury' ? '5-star resort' : tripType==='budget' ? 'Budget hostel/guesthouse' : '3-4 star hotel',
      currency: '₹'
    };
  },

  generatePackingList(tempPref, tripType, duration) {
    const base = ['Valid ID / passport','Phone charger & power bank','First aid kit','Cash + cards','Camera'];
    const cold = ['Heavy jacket','Thermal innerwear','Gloves & beanie','Snow boots','Hand warmers','Lip balm'];
    const hot  = ['Sunscreen SPF 50+','Sunglasses','Light cotton clothes','Flip flops','Insect repellent','Reusable water bottle'];
    const mild = ['Light jacket','Layers (t-shirt + sweater)','Comfortable walking shoes','Umbrella'];
    const adv  = ['Trek shoes','Backpack 30L','Energy bars','Headlamp','Rain poncho'];
    const beach= ['Swimwear','Beach towel','Waterproof bag','Rashguard'];
    let list = [...base, ...(tempPref==='cold' ? cold : tempPref==='hot' ? hot : mild)];
    if (tripType==='adventure') list = [...list, ...adv];
    if (tripType==='beach')     list = [...list, ...beach];
    if (duration > 5) list.push('Laundry bag','Clothesline');
    return [...new Set(list)];
  }
};

// ═══════════════════════════════════════════════════════════════════
// RECOMMENDATION ENGINE (Hybrid: rule + behaviour + content)
// ═══════════════════════════════════════════════════════════════════
const RecoEngine = {
  rulesBasedRecs(wd) {
    const recs = [];
    const { temp, weather_main, humidity, wind_speed } = wd;
    const main = (weather_main || '').toLowerCase();
    if (temp >= 35) recs.push({ type:'clothing', icon:'👕', text:'Wear light breathable fabrics. Avoid dark colours.', priority:'high' });
    else if (temp >= 25) recs.push({ type:'clothing', icon:'👔', text:'Light cotton or linen clothing is ideal.', priority:'low' });
    else if (temp >= 15) recs.push({ type:'clothing', icon:'🧥', text:'Light jacket recommended for evenings.', priority:'medium' });
    else recs.push({ type:'clothing', icon:'🧣', text:'Warm layers essential — scarf and gloves suggested.', priority:'high' });
    if (['rain','drizzle','thunderstorm'].includes(main))
      recs.push({ type:'gear', icon:'☂️', text:'Carry a waterproof umbrella or raincoat!', priority:'high' });
    if (main === 'clear' && temp > 28)
      recs.push({ type:'health', icon:'🧴', text:'Apply SPF 30+ sunscreen. UV index may be high.', priority:'medium' });
    if (temp > 32 || humidity > 80)
      recs.push({ type:'health', icon:'💧', text:'Stay hydrated — drink at least 3 litres of water today.', priority:'high' });
    return recs;
  },
  behaviorRecs(history) {
    if (!history || history.length < 3) return [];
    const counts = {};
    history.forEach(s => { counts[s.city] = (counts[s.city]||0) + 1; });
    const top = Object.entries(counts).sort((a,b)=>b[1]-a[1])[0];
    return top ? [{ type:'personalized', icon:'🔮', text:`You frequently check ${top[0]} — set it as your default city!`, priority:'low' }] : [];
  },
  contentRecs(wd, prefs) {
    const recs = [];
    const { temp, weather_main } = wd;
    const pref = prefs?.tempPref || '';
    if (pref==='cold' && temp > 25) recs.push({ type:'travel', icon:'🏔️', text:'Prefer cooler destinations? Try Manali or Shimla!', priority:'medium' });
    else if (pref==='hot' && temp < 15) recs.push({ type:'travel', icon:'🏖️', text:'Feeling cold? Users like you love Goa right now!', priority:'medium' });
    const main = (weather_main||'').toLowerCase();
    if (['rain','thunderstorm'].includes(main)) recs.push({ type:'activity', icon:'🏠', text:'Perfect indoor day — museums, cafes, or a good film!', priority:'medium' });
    return recs;
  }
};

// ═══════════════════════════════════════════════════════════════════
// WEATHER FETCH (core service)
// ═══════════════════════════════════════════════════════════════════
async function fetchWeatherData(city, lat, lon) {
  if (!API_KEY) throw new Error('Weather API key not configured. Add OPENWEATHER_API_KEY to .env');
  const params = (lat && lon) ? `lat=${lat}&lon=${lon}` : `q=${encodeURIComponent(city)}`;
  const [curR, fcR] = await Promise.all([
    axios.get(`${OWM_BASE}/weather?${params}&appid=${API_KEY}&units=metric`),
    axios.get(`${OWM_BASE}/forecast?${params}&appid=${API_KEY}&units=metric`)
  ]);
  const c = curR.data, f = fcR.data;
  const daily = {};
  f.list.forEach(item => {
    const date = item.dt_txt.split(' ')[0], hour = item.dt_txt.split(' ')[1];
    if (!daily[date] || hour === '12:00:00') daily[date] = item;
  });
  const forecast5 = Object.values(daily).slice(0,5).map(d => ({
    date: d.dt_txt.split(' ')[0], temp_max: Math.round(d.main.temp_max), temp_min: Math.round(d.main.temp_min),
    temp: Math.round(d.main.temp), condition: d.weather[0].description, weather_main: d.weather[0].main,
    icon: d.weather[0].icon, humidity: d.main.humidity, wind: Math.round(d.wind.speed*3.6),
    rainProb: Math.round((d.pop||0)*100)
  }));
  const sunrise = new Date(c.sys.sunrise*1000).toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit',hour12:true});
  const sunset  = new Date(c.sys.sunset *1000).toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit',hour12:true});
  const wd = {
    city: c.name, country: c.sys.country, lat: c.coord.lat, lon: c.coord.lon,
    temp: Math.round(c.main.temp), feels_like: Math.round(c.main.feels_like),
    temp_min: Math.round(c.main.temp_min), temp_max: Math.round(c.main.temp_max),
    humidity: c.main.humidity, pressure: c.main.pressure,
    wind_speed: Math.round(c.wind.speed*3.6), wind_deg: c.wind.deg||0,
    condition: c.weather[0].description, weather_main: c.weather[0].main,
    visibility: c.visibility ? Math.round(c.visibility/1000) : null,
    sunrise, sunset, forecast: forecast5
  };
  const rainPred  = ML.predictRainProbability(wd);
  const tempTrend = ML.predictTemperatureTrend(wd.temp, forecast5);
  wd.ml = {
    rainProbability: rainPred.value, rainConfidence: Math.round(rainPred.confidence*100),
    tempTrend: tempTrend.trend, tempDelta: tempTrend.delta, trendConfidence: Math.round(tempTrend.confidence*100),
    alerts: ML.generateSmartAlerts(wd)
  };
  wd.recommendations = RecoEngine.rulesBasedRecs(wd);
  return wd;
}

// ═══════════════════════════════════════════════════════════════════
// SOCKET.IO — real-time live weather
// ═══════════════════════════════════════════════════════════════════
const liveCache = {};
const CACHE_TTL = 5 * 60 * 1000;

if (io && io.on) {
  io.on('connection', socket => {
    console.log(`🔌 Socket connected: ${socket.id}`);
    socket.on('subscribe:city', async city => {
      socket.join(`city:${city}`);
      socket.city = city;
      const cached = liveCache[city];
      if (cached && Date.now() - cached.ts < CACHE_TTL) {
        socket.emit('weather:update', { city, data: cached.data, fromCache: true });
      } else {
        try {
          const data = await fetchWeatherData(city);
          liveCache[city] = { data, ts: Date.now() };
          socket.emit('weather:update', { city, data });
        } catch(e) { socket.emit('weather:error', { city, message: e.message }); }
      }
    });
    socket.on('disconnect', () => console.log(`🔌 Socket disconnected: ${socket.id}`));
  });

  // Auto-refresh subscribed cities every 5 min
  setInterval(async () => {
    const cities = new Set();
    io.sockets?.sockets?.forEach(s => { if (s.city) cities.add(s.city); });
    for (const city of cities) {
      try {
        const data = await fetchWeatherData(city);
        liveCache[city] = { data, ts: Date.now() };
        io.to(`city:${city}`).emit('weather:update', { city, data, live: true });
        if (data.ml?.alerts?.length) io.to(`city:${city}`).emit('weather:alert', { city, alerts: data.ml.alerts });
      } catch(e) {}
    }
  }, 5 * 60 * 1000);
}

// ═══════════════════════════════════════════════════════════════════
// MIDDLEWARE
// ═══════════════════════════════════════════════════════════════════
app.use(cors({ origin: process.env.FRONTEND_URL || '*', credentials: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname)));
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'index.html')));

const sessionConfig = {
  secret: process.env.SESSION_SECRET || 'atmosiq-secret-2025',
  resave: false, saveUninitialized: false,
  cookie: { secure: false, maxAge: 7*24*60*60*1000 }
};
app.use(session(sessionConfig));
mongoose.connection.once('open', () => {
  if (!sessionConfig.store) {
    sessionConfig.store = MongoStore.create({ mongoUrl: MONGO_URI, ttl: 7*24*60*60, autoRemove:'native' });
  }
});
app.use(passport.initialize());
app.use(passport.session());

const limiter = rateLimit({ windowMs: 15*60*1000, max: 200 });
app.use('/api/', limiter);

// ── Passport ──────────────────────────────────────────────────────
passport.serializeUser((user, done) => done(null, user._id?.toString() || user.id));
passport.deserializeUser(async (id, done) => {
  try { done(null, await DB.findUserById(id) || null); } catch(e) { done(null, null); }
});

if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET) {
  passport.use(new GoogleStrategy({ clientID: process.env.GOOGLE_CLIENT_ID, clientSecret: process.env.GOOGLE_CLIENT_SECRET, callbackURL: `${BASE_URL}/auth/google/callback` },
    async (at, rt, profile, done) => {
      try {
        let u = await DB.findUserByOAuth('googleId', profile.id);
        if (!u) u = await DB.createUser({ googleId: profile.id, email: profile.emails?.[0]?.value||'', firstName: profile.name?.givenName||profile.displayName, lastName: profile.name?.familyName||'', avatar: profile.photos?.[0]?.value||'', provider:'google' });
        done(null, u);
      } catch(e) { done(e, null); }
    }));
}
if (process.env.GITHUB_CLIENT_ID && process.env.GITHUB_CLIENT_SECRET) {
  passport.use(new GitHubStrategy({ clientID: process.env.GITHUB_CLIENT_ID, clientSecret: process.env.GITHUB_CLIENT_SECRET, callbackURL: `${BASE_URL}/auth/github/callback` },
    async (at, rt, profile, done) => {
      try {
        let u = await DB.findUserByOAuth('githubId', profile.id);
        if (!u) { const p = (profile.displayName||profile.username||'').split(' ');
          u = await DB.createUser({ githubId: profile.id, email: profile.emails?.[0]?.value||`${profile.username}@github`, firstName: p[0]||profile.username, lastName: p.slice(1).join(' ')||'', avatar: profile.photos?.[0]?.value||'', provider:'github' }); }
        done(null, u);
      } catch(e) { done(e, null); }
    }));
}

// ── Helpers ────────────────────────────────────────────────────────
const safeUser = u => ({
  id: u._id?.toString()||u.id, email: u.email, firstName: u.firstName, lastName: u.lastName,
  avatar: u.avatar||'', provider: u.provider||'email', preferences: u.preferences||{},
  stats: u.stats||{}, role: u.role||'user', createdAt: u.createdAt
});
function getUid(req) { return req.session?.passport?.user || req.session?.userId || null; }

// ═══════════════════════════════════════════════════════════════════
// AUTH ROUTES
// ═══════════════════════════════════════════════════════════════════
app.post('/auth/signup', async (req, res) => {
  try {
    const { firstName, lastName, email, password } = req.body;
    if (!firstName||!email||!password) return res.status(400).json({ error:'All fields required.' });
    if (password.length < 8) return res.status(400).json({ error:'Password must be at least 8 characters.' });
    if (await DB.findUserByEmail(email)) return res.status(409).json({ error:'Email already registered.' });
    const hashed = await bcrypt.hash(password, 12);
    const user = await DB.createUser({ email: email.toLowerCase(), password: hashed, firstName, lastName: lastName||'', provider:'email' });
    req.session.userId = user._id?.toString()||user.id;
    req.login(user, ()=>{});
    res.json({ success:true, user: safeUser(user) });
  } catch(e) { console.error('Signup:', e); res.status(500).json({ error:'Signup failed.' }); }
});

app.post('/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email||!password) return res.status(400).json({ error:'Email and password required.' });
    const user = await DB.findUserByEmail(email);
    if (!user) return res.status(401).json({ error:'Incorrect email or password.' });
    const pwd = user.password || (dbConnected ? (await User.findById(user._id).select('+password'))?.password : user.password);
    if (!pwd) return res.status(401).json({ error:'Please use Google or GitHub to sign in.' });
    if (!await bcrypt.compare(password, pwd)) return res.status(401).json({ error:'Incorrect email or password.' });
    req.session.userId = user._id?.toString()||user.id;
    req.login(user, ()=>{});
    res.json({ success:true, user: safeUser(user) });
  } catch(e) { console.error('Login:', e); res.status(500).json({ error:'Login failed.' }); }
});

app.post('/auth/logout', (req, res) => {
  req.session.destroy(()=>{}); req.logout(()=>{});
  res.json({ success:true });
});

app.get('/auth/me', async (req, res) => {
  const uid = getUid(req);
  if (!uid) return res.status(401).json({ error:'Not authenticated' });
  const user = await DB.findUserById(uid);
  if (!user) return res.status(401).json({ error:'User not found' });
  res.json({ user: safeUser(user) });
});

app.post('/auth/forgot', async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error:'Email required' });
  const user = await DB.findUserByEmail(email);
  if (!user) return res.status(404).json({ error:'No account found.' });
  const otp = String(Math.floor(100000 + Math.random()*900000));
  memOtpStore[email.toLowerCase()] = { otp, expires: Date.now()+600000 };
  console.log(`\n📧 OTP for ${email}: ${otp}\n`);
  res.json({ success:true, message:'Reset code sent (check server console in demo mode).' });
});

app.post('/auth/verify-otp', (req, res) => {
  const { email, otp } = req.body;
  const stored = memOtpStore[email?.toLowerCase()];
  if (!stored || stored.otp !== otp || Date.now() > stored.expires)
    return res.status(400).json({ error:'Invalid or expired code.' });
  res.json({ success:true });
});

app.post('/auth/reset', async (req, res) => {
  const { email, otp, newPassword } = req.body;
  const stored = memOtpStore[email?.toLowerCase()];
  if (!stored || stored.otp !== otp) return res.status(400).json({ error:'Invalid reset token.' });
  if (newPassword.length < 8) return res.status(400).json({ error:'Password too short.' });
  const hashed = await bcrypt.hash(newPassword, 12);
  const user = await DB.findUserByEmail(email);
  if (dbConnected && user) await User.findByIdAndUpdate(user._id, { password: hashed });
  else if (user) user.password = hashed;
  delete memOtpStore[email.toLowerCase()];
  res.json({ success:true });
});

app.get('/auth/google', passport.authenticate('google',{scope:['profile','email']}));
app.get('/auth/google/callback', passport.authenticate('google',{failureRedirect:'/?error=oauth'}),
  (req,res) => { req.session.userId = req.user._id?.toString()||req.user.id; res.redirect('/?loggedin=1'); });
app.get('/auth/github', passport.authenticate('github',{scope:['user:email']}));
app.get('/auth/github/callback', passport.authenticate('github',{failureRedirect:'/?error=oauth'}),
  (req,res) => { req.session.userId = req.user._id?.toString()||req.user.id; res.redirect('/?loggedin=1'); });

// ═══════════════════════════════════════════════════════════════════
// WEATHER SERVICE
// ═══════════════════════════════════════════════════════════════════
app.get('/api/weather', async (req, res) => {
  try {
    const { city, lat, lon } = req.query;
    if (!city && !(lat && lon)) return res.status(400).json({ error:'City or coordinates required' });
    const data = await fetchWeatherData(city, lat, lon);
    const uid = getUid(req);
    if (uid) DB.saveSearch(uid, { city:data.city, country:data.country, lat:data.lat, lon:data.lon, weatherSnapshot:{ temp:data.temp, condition:data.condition, weather_main:data.weather_main, humidity:data.humidity, wind_speed:data.wind_speed }, mlPrediction:{ rainProb:data.ml.rainProbability, tempTrend:data.ml.tempTrend, confidence:data.ml.rainConfidence/100 } });
    const mcp = getMCPContext(req);
    mcp.lastCity = data.city; mcp.lastWeather = data;
    req.session.lastCity = data.city;
    res.json({ success:true, data });
  } catch(e) {
    const s = e.response?.status === 404 ? 404 : 500;
    res.status(s).json({ error: s===404 ? `City "${req.query.city}" not found.` : (e.message||'Weather fetch failed') });
  }
});

// Multi-city comparison
app.get('/api/compare', async (req, res) => {
  try {
    const cities = (req.query.cities||'').split(',').map(c=>c.trim()).filter(Boolean).slice(0,5);
    if (cities.length < 2) return res.status(400).json({ error:'Provide at least 2 cities' });
    const results = await Promise.allSettled(cities.map(c => fetchWeatherData(c)));
    res.json({ success:true, data: results.map((r,i) => r.status==='fulfilled' ? r.value : { city:cities[i], error:r.reason.message }) });
  } catch(e) { res.status(500).json({ error:e.message }); }
});

// ── ML Service ─────────────────────────────────────────────────────
app.post('/api/ml/predict', async (req, res) => {
  try {
    const { city } = req.body;
    if (!city) return res.status(400).json({ error:'City required' });
    const wd = await fetchWeatherData(city);
    const rain  = ML.predictRainProbability(wd);
    const trend = ML.predictTemperatureTrend(wd.temp, wd.forecast);
    const alerts = ML.generateSmartAlerts(wd);
    res.json({ success:true, city:wd.city, predictions:{
      rain:{ probability:rain.value, confidence:Math.round(rain.confidence*100), label:rain.value>70?'Very Likely':rain.value>40?'Possible':'Unlikely' },
      temperature:{ trend:trend.trend, delta:trend.delta, confidence:Math.round(trend.confidence*100) },
      alerts
    }, forecast:wd.forecast });
  } catch(e) { res.status(500).json({ error:e.message }); }
});

// ── NLP Trip Planner ───────────────────────────────────────────────
app.post('/api/trip/nlp', async (req, res) => {
  try {
    const { query } = req.body;
    if (!query) return res.status(400).json({ error:'Query required' });
    const parsed = NLP.parseTripQuery(query);
    const destinations = NLP.suggestDestinations(parsed);
    const topDest = destinations[0];
    let forecast = [];
    if (topDest && API_KEY) {
      try { const wx = await fetchWeatherData(topDest.city); forecast = wx.forecast; } catch(e) {}
    }
    const duration = parsed.duration || 3;
    const budget   = NLP.generateBudgetPlan(topDest?.city||'destination', duration, parsed.travelers, parsed.budget, parsed.tripType);
    const itinerary = NLP.generateItinerary(topDest?.city||'destination', duration, parsed.tripType, forecast);
    const packing  = NLP.generatePackingList(parsed.tempPreference, parsed.tripType, duration);
    const uid = getUid(req);
    let savedTrip = null;
    if (uid && topDest) {
      savedTrip = await DB.saveTrip(uid, { destination:topDest.city, fromDate:new Date(), toDate:new Date(Date.now()+duration*86400000), budget:budget.total, travelers:parsed.travelers, preferences:parsed.tripType, forecast, packingList:packing, itinerary, budgetPlan:budget, nlpQuery:query });
    }
    res.json({ success:true, parsed, destinations, topDestination:topDest, duration, budget, itinerary, packingList:packing, forecast, tripId:savedTrip?._id });
  } catch(e) { console.error('NLP Trip:', e); res.status(500).json({ error:e.message }); }
});

// Standard trip planner
app.post('/api/trip', async (req, res) => {
  try {
    const { city, fromDate, toDate, notes } = req.body;
    if (!city||!fromDate||!toDate) return res.status(400).json({ error:'City and dates required' });
    const data = await fetchWeatherData(city);
    const days = Math.ceil((new Date(toDate)-new Date(fromDate))/86400000);
    const packing = NLP.generatePackingList(data.temp<15?'cold':data.temp>28?'hot':'mild', 'general', days);
    const uid = getUid(req);
    let saved = null;
    if (uid) saved = await DB.saveTrip(uid, { destination:data.city, fromDate:new Date(fromDate), toDate:new Date(toDate), forecast:data.forecast, packingList:packing, notes:notes||'' });
    res.json({ success:true, city:data.city, country:data.country, forecast:data.forecast, packingList:packing, tripId:saved?._id });
  } catch(e) { res.status(500).json({ error:e.message }); }
});

// ── Recommendations ────────────────────────────────────────────────
app.get('/api/recommendations', async (req, res) => {
  try {
    const { city } = req.query;
    const uid = getUid(req);
    let wd = null, recs = [];
    if (city) { wd = await fetchWeatherData(city); recs = RecoEngine.rulesBasedRecs(wd); }
    if (uid) {
      const history = await DB.getSearchHistory(uid, 20);
      recs = [...recs, ...RecoEngine.behaviorRecs(history)];
      const user = await DB.findUserById(uid);
      if (user && wd) recs = [...recs, ...RecoEngine.contentRecs(wd, user.preferences)];
    }
    const travelSuggestions = [
      { city:'Goa',       icon:'🏖️', reason:'Popular in winter season', tags:['beach','warm'] },
      { city:'Manali',    icon:'🏔️', reason:'Snow season at its best',   tags:['cold','adventure'] },
      { city:'Kerala',    icon:'🌴', reason:'Backwaters and monsoon magic', tags:['nature','culture'] },
      { city:'Rajasthan', icon:'🏯', reason:'Cultural heritage & desert',  tags:['culture','hot'] },
      { city:'Andaman',   icon:'🐠', reason:'Crystal waters & pristine beaches', tags:['beach','tropical'] }
    ];
    res.json({ success:true, recommendations:recs, travelSuggestions });
  } catch(e) { res.status(500).json({ error:e.message }); }
});

// ── User Dashboard ─────────────────────────────────────────────────
app.get('/api/user/dashboard', async (req, res) => {
  try {
    const uid = getUid(req);
    if (!uid) return res.status(401).json({ error:'Auth required' });
    const [user, stats, history, trips, alerts] = await Promise.all([
      DB.findUserById(uid), DB.getUserStats(uid), DB.getSearchHistory(uid,10), DB.getTrips(uid), DB.getAlerts(uid)
    ]);
    if (!user) return res.status(404).json({ error:'User not found' });
    const counts = {};
    history.forEach(s => { counts[s.city] = (counts[s.city]||0)+1; });
    const topCity = Object.entries(counts).sort((a,b)=>b[1]-a[1])[0];
    res.json({ success:true, user:safeUser(user), stats:{ ...stats, mostSearchedCity:topCity?.[0]||'N/A' }, recentSearches:history, trips, alerts, favoriteCities:user.preferences?.pinnedCities||[] });
  } catch(e) { res.status(500).json({ error:e.message }); }
});

app.put('/api/user/preferences', async (req, res) => {
  try {
    const uid = getUid(req);
    if (!uid) return res.status(401).json({ error:'Not authenticated' });
    const user = await DB.updateUser(uid, { preferences: req.body.preferences });
    res.json({ success:true, user: safeUser(user) });
  } catch(e) { res.status(500).json({ error:e.message }); }
});

// ── Alerts ─────────────────────────────────────────────────────────
app.get('/api/alerts', async (req, res) => {
  const uid = getUid(req);
  if (!uid) return res.status(401).json({ error:'Auth required' });
  res.json({ success:true, alerts: await DB.getAlerts(uid) });
});

app.post('/api/alerts', async (req, res) => {
  try {
    const uid = getUid(req);
    if (!uid) return res.status(401).json({ error:'Auth required' });
    const { city, type, threshold, message } = req.body;
    if (!city||!type) return res.status(400).json({ error:'City and type required' });
    const alert = await DB.createAlert(uid, { city, type, threshold, message:message||'' });
    res.json({ success:true, alert });
  } catch(e) { res.status(500).json({ error:e.message }); }
});

app.delete('/api/alerts/:id', async (req, res) => {
  const uid = getUid(req);
  if (!uid) return res.status(401).json({ error:'Auth required' });
  await DB.deleteAlert(uid, req.params.id);
  res.json({ success:true });
});

// ── Admin (basic) ──────────────────────────────────────────────────
app.get('/api/admin/stats', async (req, res) => {
  const uid = getUid(req);
  if (!uid) return res.status(401).json({ error:'Auth required' });
  const stats = await DB.getAdminStats();
  res.json({ success:true, stats });
});

// ── Locations ──────────────────────────────────────────────────────
app.get('/api/locations', async (req, res) => {
  const uid = getUid(req);
  if (!uid) return res.status(401).json({ error:'Auth required' });
  const locations = await DB.getLocations(uid);
  res.json({ success:true, locations });
});

app.post('/api/locations', async (req, res) => {
  try {
    const uid = getUid(req);
    if (!uid) return res.status(401).json({ error:'Auth required' });
    const loc = await DB.saveLocation(uid, req.body);
    res.json({ success:true, location:loc });
  } catch(e) { res.status(500).json({ error:e.message }); }
});

// ── MCP Context ────────────────────────────────────────────────────
const mcpStore = {};
function getMCPContext(req) {
  const sid = req.sessionID||'anon';
  if (!mcpStore[sid]) mcpStore[sid] = { lastCity:null, lastWeather:null, conversationHistory:[], lastIntent:null };
  return mcpStore[sid];
}

app.get('/api/context', (req, res) => {
  const mcp = getMCPContext(req);
  res.json({ lastCity: mcp.lastCity || req.session?.lastCity || null });
});

// ── Chat ───────────────────────────────────────────────────────────
function detectIntent(msg) {
  const m = msg.toLowerCase();
  if (/trip|travel|plan|visit|vacation|holiday|destination/i.test(m)) return 'trip';
  if (/wear|outfit|dress|clothes/i.test(m)) return 'clothing';
  if (/alert|warning|danger/i.test(m)) return 'alert';
  if (/activity|sport|outdoor|exercise|run/i.test(m)) return 'activity';
  if (/predict|forecast|ml|rain prob|will it rain/i.test(m)) return 'mlpredict';
  if (/clear|reset|new chat/i.test(m)) return 'clear';
  if (/tomorrow|next|week/i.test(m)) return 'followup';
  return 'weather';
}
function extractCity(msg) {
  const patterns = [/(?:weather|forecast|temp)\s+(?:in|at|for)\s+([A-Za-z\s]+?)(?:\?|$|,)/i, /(?:in|at|for)\s+([A-Za-z\s]+?)(?:\?|$|,)/i];
  for (const p of patterns) { const m = msg.match(p); if (m && m[1].trim().length > 1) return m[1].trim(); }
  return null;
}
function generateSmartResponse(intent, message, mcp, wd) {
  const w = wd || mcp.lastWeather;
  const cityName = w?.city || mcp.lastCity || 'your location';
  const { temp, condition, weather_main, humidity, wind_speed, feels_like } = w || {};
  switch(intent) {
    case 'clothing': {
      if (!w) break;
      let tips = temp>=35?['👕 Loose light-coloured cotton/linen','😎 Sunglasses & hat essential','🧴 SPF 50+ sunscreen','💧 Carry a water bottle']
        :temp>=25?['👗 Light cotton is perfect','👟 Sandals or sneakers','☂️ Compact umbrella handy']
        :temp>=15?['🧥 Light jacket for evenings','👖 Jeans comfortable','👟 Sneakers or casual shoes']
        :['🧣 Warm layers — fleece or wool','🧤 Gloves & scarf if below 10°C','🥾 Waterproof boots if raining'];
      if (['Rain','Drizzle','Thunderstorm'].includes(weather_main)) tips.unshift('☂️ MUST: Waterproof umbrella or rain jacket!');
      return { reply:`👗 **Outfit Guide for ${cityName} (${temp}°C):**\n\n${tips.map(t=>`• ${t}`).join('\n')}`, suggestions:['Travel tips?','Outdoor activities?','Weather alerts?'] };
    }
    case 'mlpredict': {
      if (!w?.ml) break;
      const { rainProbability, tempTrend, tempDelta } = w.ml;
      const emoji = tempTrend==='rising'?'↗️':tempTrend==='falling'?'↘️':'→';
      return { reply:`🤖 **ML Predictions for ${cityName}:**\n\n🌧️ Rain Probability: **${rainProbability}%** (${rainProbability>70?'Very Likely':rainProbability>40?'Possible':'Unlikely'})\n🌡️${emoji} Temp Trend: **${tempTrend}** (${tempDelta>0?'+':''}${tempDelta}°C over 3 days)\n\n📊 Model: RandomForest + historical patterns\n💡 Confidence: ~${w.ml.rainConfidence}%`, suggestions:['Show alerts','Plan a trip','Clothing tips?'] };
    }
    case 'trip':
      return { reply:`✈️ Try the **✈️ Smart Trip Planner** tab for full AI-powered trip planning!\n\nOr ask me naturally:\n• "Plan a 3-day cold trip under ₹15k"\n• "Suggest a beach destination for 2 people"\n• "Budget weekend getaway to the hills"`, suggestions:['3-day cold trip ₹10k','Beach trip for 2','Romantic weekend getaway'] };
    case 'alert': {
      if (!w) break;
      const alerts = ML.generateSmartAlerts(w);
      return { reply: alerts.length ? `⚠️ **Active Alerts for ${cityName}:**\n\n${alerts.map(a=>`${a.icon} [${a.level.toUpperCase()}] ${a.message}`).join('\n\n')}` : `✅ **No alerts for ${cityName}** — all clear!\n\n🌡️ ${temp}°C | 💧 ${humidity}% | 💨 ${wind_speed} km/h`, suggestions:['Clothing tips?','Good for travel?','ML predictions?'] };
    }
    case 'clear':
      mcp.conversationHistory = [];
      return { reply:`🔄 Chat cleared! I'm AtmosIQ AI — ask about weather, ML predictions, clothing, travel, or alerts!`, suggestions:['Weather in Mumbai','Plan a trip','Compare cities'] };
    default: {
      if (!w) break;
      const fc5 = (w.forecast||[]).slice(0,5).map((d,i)=>`• ${i===0?'Today':new Date(d.date+'T12:00:00').toLocaleDateString('en-US',{weekday:'short'})}: ${d.temp_max}°/${d.temp_min}° — ${d.condition}`).join('\n');
      return { reply:`🌤️ **${cityName} Weather:**\n\n🌡️ **${temp}°C** (Feels ${feels_like}°C)\n☁️ ${condition} | 💧 ${humidity}% | 💨 ${wind_speed} km/h\n\n🤖 ML: Rain ${w.ml?.rainProbability||'?'}% | Trend: ${w.ml?.tempTrend||'stable'}\n\n📅 **5-Day Forecast:**\n${fc5}`, suggestions:['Clothing tips?','ML predictions','Travel tips?'] };
    }
  }
  return { reply:`Search for a city first, then ask me about weather, clothing, ML predictions, or travel! 🌍`, suggestions:['Weather in Mumbai','Plan a trip'] };
}

app.post('/chat', async (req, res) => {
  try {
    const { message } = req.body;
    if (!message?.trim()) return res.status(400).json({ error:'Message required' });
    const mcp = getMCPContext(req);
    const intent = detectIntent(message);
    const city = extractCity(message);
    let wd = null;
    if (city && API_KEY) {
      try { wd = await fetchWeatherData(city); mcp.lastCity = wd.city; mcp.lastWeather = wd; req.session.lastCity = wd.city; }
      catch(e) { if (e.response?.status===404) return res.json({ reply:`❌ Couldn't find **"${city}"**. Check the spelling and try again.`, suggestions:['Weather in Mumbai','Weather in London'] }); }
    }
    const response = generateSmartResponse(intent, message, mcp, wd);
    mcp.conversationHistory.push({ role:'user', content:message }, { role:'assistant', content:response.reply });
    if (mcp.conversationHistory.length > 20) mcp.conversationHistory = mcp.conversationHistory.slice(-20);
    mcp.lastIntent = intent;
    const uid = getUid(req);
    if (uid) { DB.saveChatMessage(uid,'user',message,mcp.lastCity||''); DB.saveChatMessage(uid,'agent',response.reply,mcp.lastCity||''); }
    res.json({ reply:response.reply, suggestions:response.suggestions||[], intent, city:mcp.lastCity, weatherFetched:!!wd });
  } catch(e) { res.status(500).json({ reply:'❌ Something went wrong. Try again!', suggestions:[] }); }
});

// ── Health & Static ────────────────────────────────────────────────
app.get('/health', (req,res) => res.json({ status:'ok', version:'2.0.0', db:dbConnected?'mongodb':'memory', features:['Socket.io','ML','NLP','Admin','JWT-ready'], openweather:!!API_KEY }));
app.get('/dashboard', (req,res) => res.sendFile(path.join(__dirname,'dashboard.html')));
app.get('/sw.js',         (req,res) => res.sendFile(path.join(__dirname,'sw.js')));
app.get('/manifest.json', (req,res) => res.sendFile(path.join(__dirname,'manifest.json')));

// ─── Start ─────────────────────────────────────────────────────────
server.listen(PORT, () => {
  console.log(`\n🌤️  AtmosIQ v2.0 → http://localhost:${PORT}`);
  console.log(`🔌  Socket.io: ✅ real-time enabled`);
  console.log(`🤖  ML Engine: ✅ RandomForest predictions`);
  console.log(`✈️   NLP Planner: ✅ natural language trips`);
  console.log(`🗄️   Database: ${dbConnected?'✅ MongoDB':'⚠️  In-memory'}`);
  console.log(`🌦️   Weather API: ${API_KEY?'✅':'❌ Add OPENWEATHER_API_KEY to .env'}\n`);
});
