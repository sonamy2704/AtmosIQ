// PM2 Ecosystem Config — run: pm2 start ecosystem.config.js
module.exports = {
  apps: [
    {
      name:         'skyagent-backend',
      script:       'server.js',
      cwd:          '/home/ec2-user/weather-agent/backend',
      instances:    'max',
      exec_mode:    'cluster',
      watch:        false,
      env: {
        NODE_ENV: 'production',
        PORT:     3001,
      },
      error_file:   '/home/ec2-user/.pm2/logs/skyagent-error.log',
      out_file:     '/home/ec2-user/.pm2/logs/skyagent-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss',
      max_restarts: 10,
      restart_delay: 4000,
    }
  ]
};
