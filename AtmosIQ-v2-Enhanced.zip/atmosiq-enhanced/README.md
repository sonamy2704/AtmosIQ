# 🌤️ AtmosIQ v2.0 — Advanced AI Weather Intelligence Platform

Production-ready full-stack weather app with ML, Socket.io real-time, NLP trip planning, multi-city comparison, admin analytics, and stunning animated image slider.

## 🚀 What's New in v2.0

| Feature | Description |
|---|---|
| 🔌 Socket.io Real-Time | Live weather updates without page reload |
| 🤖 ML Predictions | RandomForest rain probability + temp trend |
| 🧠 NLP Trip Planner | Natural language: "Plan a 3-day cold trip under ₹10k" |
| ⚖️ Multi-City Compare | Side-by-side comparison table + chart |
| 🛡️ Admin Panel | Analytics dashboard with top cities chart |
| 🌧️ Rain Prob Chart | 5-day rain probability visualization |
| 🖼️ Ken Burns Slider | 10 stunning nature images with parallax effect |
| 🎯 Smart Alerts | ML-generated heat/storm/frost/wind warnings |
| 🏆 Hybrid Reco Engine | Rule + Behaviour + Content-based recommendations |

## ⚡ Quick Start

```bash
cd backend
npm install
cp .env.example .env
# Add your OPENWEATHER_API_KEY to .env
npm start
# Open http://localhost:3001
```

## 🏗️ Architecture

```
AtmosIQ v2.0 (Microservices Pattern)
├── Auth Service    → /auth/* (bcrypt + JWT + sessions + Google/GitHub OAuth)
├── Weather Service → /api/weather, /api/compare
├── ML Service      → /api/ml/predict (RandomForest node.js engine)
├── NLP Trip Svc    → /api/trip/nlp (natural language parser)
├── Reco Service    → /api/recommendations (hybrid engine)
├── Alert Service   → /api/alerts
├── Admin Service   → /api/admin/stats
├── Socket.io       → Real-time weather push (auto-refresh 5min)
└── MongoDB         → Users, Searches, Trips, Alerts, Chat, ML logs
```

## 📡 Key API Routes

```
GET  /api/weather?city=Mumbai           Weather + ML predictions
GET  /api/compare?cities=Mumbai,Delhi   Multi-city comparison
POST /api/ml/predict  {city}            ML rain/trend predictions
POST /api/trip/nlp    {query}           NLP trip generation
GET  /api/user/dashboard                User stats + history
GET  /api/admin/stats                   Admin analytics
Socket: subscribe:city / weather:update / weather:alert
```

## 🤖 ML Engine

Node.js RandomForest simulation:
- Rain probability: humidity + pressure + wind + condition → 0-100%
- Temp trend: 3-day forecast delta → rising/stable/falling
- Smart alerts: heat/storm/frost/wind auto-detection
- Confidence scores for all predictions

## 🧠 NLP Extracts From Queries

Duration, budget (₹/$/k notation), temperature preference (cold/hot/mild), travelers, trip type (adventure/beach/luxury/budget/family/romantic), month → generates destinations + itinerary + budget plan + packing list

## 🔐 Security

bcrypt (cost 12) · express-rate-limit · JWT tokens · Passport OAuth · CORS · Input validation

## 🚀 Deployment

```
Backend:  Render or Railway (set env vars, start: node server.js)
Database: MongoDB Atlas (MONGODB_URI=mongodb+srv://...)
Frontend: Served by Express (same process)
```
