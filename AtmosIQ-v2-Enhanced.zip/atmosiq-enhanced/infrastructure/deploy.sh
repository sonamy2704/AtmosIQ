#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════
# SkyAgent - Full AWS Deployment Script
# Deploys: S3 (frontend) + EC2 (backend)
# Requirements: AWS CLI configured, Node.js 18+
# Usage: chmod +x deploy.sh && ./deploy.sh
# ═══════════════════════════════════════════════════════════════════════════════

set -e  # Exit on any error

# ── Config — edit these ────────────────────────────────────────────────────────
APP_NAME="skyagent-weather"
AWS_REGION="ap-south-1"          # Mumbai region (closest to India)
S3_BUCKET="${APP_NAME}-frontend"
EC2_KEY_PAIR="${APP_NAME}-key"
EC2_INSTANCE_TYPE="t3.micro"     # Free tier eligible
EC2_AMI="ami-0f58b397bc5c1f2e8"  # Amazon Linux 2023 (ap-south-1)

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║   🌤️  SkyAgent AWS Deployment            ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# ── Step 1: Build Frontend ─────────────────────────────────────────────────────
echo "📦 [1/6] Building React frontend..."
cd frontend
npm install --silent
REACT_APP_API_URL="http://${EC2_PUBLIC_IP}:3001" npm run build -- --silent
cd ..
echo "✅ Frontend built successfully"

# ── Step 2: Create S3 Bucket ──────────────────────────────────────────────────
echo ""
echo "☁️  [2/6] Creating S3 bucket for static hosting..."

if aws s3api head-bucket --bucket "${S3_BUCKET}" --region "${AWS_REGION}" 2>/dev/null; then
  echo "   ⚠️  Bucket already exists, skipping creation"
else
  aws s3api create-bucket \
    --bucket "${S3_BUCKET}" \
    --region "${AWS_REGION}" \
    --create-bucket-configuration LocationConstraint="${AWS_REGION}"

  # Enable static website hosting
  aws s3 website "s3://${S3_BUCKET}" \
    --index-document index.html \
    --error-document index.html

  # Set public read policy
  aws s3api put-public-access-block \
    --bucket "${S3_BUCKET}" \
    --public-access-block-configuration \
    "BlockPublicAcls=false,IgnorePublicAcls=false,BlockPublicPolicy=false,RestrictPublicBuckets=false"

  aws s3api put-bucket-policy \
    --bucket "${S3_BUCKET}" \
    --policy "{
      \"Version\": \"2012-10-17\",
      \"Statement\": [{
        \"Sid\": \"PublicReadGetObject\",
        \"Effect\": \"Allow\",
        \"Principal\": \"*\",
        \"Action\": \"s3:GetObject\",
        \"Resource\": \"arn:aws:s3:::${S3_BUCKET}/*\"
      }]
    }"
  echo "✅ S3 bucket created and configured"
fi

# ── Step 3: Upload Frontend to S3 ─────────────────────────────────────────────
echo ""
echo "📤 [3/6] Uploading frontend to S3..."
aws s3 sync frontend/build/ "s3://${S3_BUCKET}/" \
  --delete \
  --cache-control "max-age=31536000,public" \
  --exclude "index.html" \
  --region "${AWS_REGION}"

# Upload index.html with no-cache for fresh deployments
aws s3 cp frontend/build/index.html "s3://${S3_BUCKET}/index.html" \
  --cache-control "no-cache" \
  --region "${AWS_REGION}"

S3_URL="http://${S3_BUCKET}.s3-website.${AWS_REGION}.amazonaws.com"
echo "✅ Frontend deployed → ${S3_URL}"

# ── Step 4: Create EC2 Security Group ────────────────────────────────────────
echo ""
echo "🔒 [4/6] Setting up EC2 security group..."

SG_ID=$(aws ec2 describe-security-groups \
  --filters "Name=group-name,Values=${APP_NAME}-sg" \
  --query "SecurityGroups[0].GroupId" \
  --output text --region "${AWS_REGION}" 2>/dev/null || echo "None")

if [ "${SG_ID}" = "None" ] || [ -z "${SG_ID}" ]; then
  SG_ID=$(aws ec2 create-security-group \
    --group-name "${APP_NAME}-sg" \
    --description "SkyAgent Weather App Security Group" \
    --region "${AWS_REGION}" \
    --query "GroupId" --output text)

  aws ec2 authorize-security-group-ingress --group-id "${SG_ID}" --protocol tcp --port 22   --cidr 0.0.0.0/0 --region "${AWS_REGION}"
  aws ec2 authorize-security-group-ingress --group-id "${SG_ID}" --protocol tcp --port 80   --cidr 0.0.0.0/0 --region "${AWS_REGION}"
  aws ec2 authorize-security-group-ingress --group-id "${SG_ID}" --protocol tcp --port 3001 --cidr 0.0.0.0/0 --region "${AWS_REGION}"
  echo "✅ Security group created: ${SG_ID}"
else
  echo "   ⚠️  Security group already exists: ${SG_ID}"
fi

# ── Step 5: Launch EC2 Instance ───────────────────────────────────────────────
echo ""
echo "🖥️  [5/6] Launching EC2 instance..."

# User data script to bootstrap the backend
USER_DATA=$(cat <<'USERDATA'
#!/bin/bash
yum update -y
curl -fsSL https://rpm.nodesource.com/setup_18.x | bash -
yum install -y nodejs git

# Install PM2 for process management
npm install -g pm2

# Clone / pull app (replace with your repo URL)
APP_DIR=/home/ec2-user/weather-agent
mkdir -p $APP_DIR/backend
cd $APP_DIR

# Upload backend files via S3 or git — placeholder:
# git clone https://github.com/YOUR_REPO/weather-agent.git .

cd backend
npm install --production

# Create .env (replace values)
cat > .env <<ENV
OPENWEATHER_API_KEY=REPLACE_WITH_YOUR_KEY
PORT=3001
SESSION_SECRET=$(openssl rand -hex 32)
FRONTEND_URL=*
ENV

# Start with PM2
pm2 start server.js --name skyagent-backend
pm2 startup
pm2 save
USERDATA
)

INSTANCE_ID=$(aws ec2 run-instances \
  --image-id "${EC2_AMI}" \
  --instance-type "${EC2_INSTANCE_TYPE}" \
  --key-name "${EC2_KEY_PAIR}" \
  --security-group-ids "${SG_ID}" \
  --user-data "${USER_DATA}" \
  --tag-specifications "ResourceType=instance,Tags=[{Key=Name,Value=${APP_NAME}-backend}]" \
  --region "${AWS_REGION}" \
  --query "Instances[0].InstanceId" \
  --output text)

echo "   Waiting for instance to start..."
aws ec2 wait instance-running --instance-ids "${INSTANCE_ID}" --region "${AWS_REGION}"

EC2_PUBLIC_IP=$(aws ec2 describe-instances \
  --instance-ids "${INSTANCE_ID}" \
  --query "Reservations[0].Instances[0].PublicIpAddress" \
  --output text --region "${AWS_REGION}")

echo "✅ EC2 launched: ${INSTANCE_ID} → ${EC2_PUBLIC_IP}"

# ── Step 6: Summary ───────────────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║   🎉  Deployment Complete!                               ║"
echo "╠══════════════════════════════════════════════════════════╣"
echo "║                                                          ║"
echo "║  Frontend:  ${S3_URL}"
echo "║  Backend:   http://${EC2_PUBLIC_IP}:3001"
echo "║  EC2 ID:    ${INSTANCE_ID}"
echo "║                                                          ║"
echo "║  Next steps:                                             ║"
echo "║  1. SSH: ssh -i ${EC2_KEY_PAIR}.pem ec2-user@${EC2_PUBLIC_IP}"
echo "║  2. Add your API key to /home/ec2-user/weather-agent/backend/.env"
echo "║  3. Rebuild frontend with EC2 IP and re-upload to S3    ║"
echo "║  4. (Optional) Set up CloudFront for HTTPS              ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""
