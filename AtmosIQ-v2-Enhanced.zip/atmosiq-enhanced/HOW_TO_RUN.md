# 🚀 How to Run AtmosIQ v2.0

## Step 1 — Prerequisites
- Node.js 18+ installed
- MongoDB (optional — falls back to memory)
- Free OpenWeather API key from openweathermap.org

## Step 2 — Install
```bash
cd backend
npm install
```

## Step 3 — Configure
```bash
cp .env.example .env
```
Open `.env` and set:
```
OPENWEATHER_API_KEY=your_key_here
MONGODB_URI=mongodb://localhost:27017/atmosiq   (optional)
```

## Step 4 — Run
```bash
npm start          # Production
npm run dev        # Development (auto-reload with nodemon)
```

## Step 5 — Open
```
http://localhost:3001
```

## ✅ Feature Checklist

After running, you should see:
- [ ] Auth page with animated Ken Burns image slider (10 nature photos)
- [ ] Slide captions + progress bar
- [ ] After login: search any city
- [ ] 🤖 ML tab — rain probability gauge + temperature trend
- [ ] 🧠 AI Trip tab — type natural language, get full itinerary
- [ ] ⚖️ Compare tab — enter 4 cities, compare in table + chart
- [ ] 🛡️ Admin tab — analytics (requires MongoDB for real data)
- [ ] ⚡ Socket.io live badge in Charts tab (after search)
- [ ] Weather alerts from ML engine

## 🔧 Troubleshooting

**"Weather API key not configured"**
→ Add OPENWEATHER_API_KEY to your .env file

**MongoDB connection failed**
→ App runs fine without MongoDB (uses in-memory storage)
→ For persistence: install MongoDB or use Atlas

**socket.io not found**
→ Run: npm install socket.io

**Port in use**
→ Change PORT=3002 in .env
